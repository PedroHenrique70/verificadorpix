package com.seuprojeto.detectorpix.service;

import com.seuprojeto.detectorpix.model.Email;
import com.seuprojeto.detectorpix.model.TipoLista;
import com.seuprojeto.detectorpix.repository.EmailRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class EmailService {

    private final EmailRepository repository;

    public EmailService(EmailRepository repository) {
        this.repository = repository;
    }

    public String verificarEmail(String endereco) {
        Optional<Email> emailOpt = repository.findByEndereco(endereco);

        if (emailOpt.isPresent()) {
            TipoLista tipo = emailOpt.get().getTipo();
            return tipo == TipoLista.WHITELIST ? "Email confiável." : "Cuidado! Este email é suspeito.";
        }

        return "Email não encontrado na lista.";
    }

    public Email salvarEmail(Email email) {
        return repository.save(email);
    }
}

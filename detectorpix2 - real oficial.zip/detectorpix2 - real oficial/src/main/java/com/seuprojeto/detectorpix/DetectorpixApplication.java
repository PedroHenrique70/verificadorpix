package com.seuprojeto.detectorpix;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DetectorpixApplication {

	public static void main(String[] args) {
		SpringApplication.run(DetectorpixApplication.class, args);
	}

}

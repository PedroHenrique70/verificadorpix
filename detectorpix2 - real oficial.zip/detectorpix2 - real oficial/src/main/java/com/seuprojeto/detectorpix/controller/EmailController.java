package com.seuprojeto.detectorpix.controller;

import com.seuprojeto.detectorpix.model.Email;
import com.seuprojeto.detectorpix.service.EmailService;
import org.springframework.web.bind.annotation.*;



@RestController
@RequestMapping("/api/emails")
public class EmailController {

    private final EmailService service;

    public EmailController(EmailService service) {
        this.service = service;
    }

    // Cadastrar email
    @PostMapping
    public Email cadastrar(@RequestBody Email email) {
        return service.salvarEmail(email);
    }

    // Verificar email
    @GetMapping("/verificar")
    public String verificar(@RequestParam String endereco) {
        return service.verificarEmail(endereco);
    }

}

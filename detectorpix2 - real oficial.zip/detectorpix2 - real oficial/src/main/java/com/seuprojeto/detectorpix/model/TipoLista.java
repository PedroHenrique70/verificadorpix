package com.seuprojeto.detectorpix.model;

public enum TipoLista {
    WHITELIST,
    BLACKLIST
}

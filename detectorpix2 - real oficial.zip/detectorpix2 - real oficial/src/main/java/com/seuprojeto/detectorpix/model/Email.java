package com.seuprojeto.detectorpix.model;

import jakarta.persistence.*;

@Entity (name = "email")
public class Email {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String endereco;

    @Enumerated(EnumType.STRING)
    private TipoLista tipo;

    // Getters e Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getEndereco() { return endereco; }
    public void setEndereco(String endereco) { this.endereco = endereco; }

    public TipoLista getTipo() { return tipo; }
    public void setTipo(TipoLista tipo) { this.tipo = tipo; }
}
